
/**
 * Sinnbefreite Test-Klasse um Vererbung zu ueben
 * 
 * @author   Michael Schaefers 
 * @version  2015/11/10
 */
interface I {                                               // Interface ist automatisch public abstract
    
    void om();                                              // Methode ist automatisch public abstract
    
}// interface
